from flask import Flask, request, render_template, jsonify
import numpy as np
import pandas as pd
import os
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from keras.models import load_model
from PIL import Image
import cv2
import joblib
from werkzeug.utils import secure_filename

# Initialize the Flask application
app = Flask(__name__)

# Load the CNN model for brain tumor classification
cnn_model = load_model('BrainTumor10EpochsCategorical.h5')

# Load the LSTM model for VEGF prediction and the scaler
lstm_model = load_model('vegf_model.h5')
scaler = joblib.load('scaler.pkl')

# Load the symptom data for Medinosis prediction
df_train = pd.read_csv('Prototype.csv')
df_test = pd.read_csv('Prototype1.csv')

# Generate disease mappings from 'prognosis' column
unique_diseases = df_train['prognosis'].unique()
disease_dict = {disease: idx for idx, disease in enumerate(unique_diseases)}
reverse_disease_dict = {v: k for k, v in disease_dict.items()}

# Replace disease names with numerical values in both train and test datasets
df_train['prognosis'] = df_train['prognosis'].map(disease_dict)
df_test['prognosis'] = df_test['prognosis'].map(disease_dict)

# Prepare the training and testing data
l1 = ['itching', 'skin_rash', 'nodal_skin_eruptions', 'continuous_sneezing', 
      'shivering', 'chills', 'joint_pain', 'stomach_pain', 'acidity', 
      'ulcers_on_tongue', 'muscle_wasting', 'vomiting', 'burning_micturition', 
      'spotting_ urination', 'fatigue', 'weight_gain', 'anxiety', 'cold_hands_and_feets', 
      'mood_swings', 'weight_loss', 'restlessness', 'lethargy', 'patches_in_throat', 
      'irregular_sugar_level', 'cough', 'high_fever', 'sunken_eyes', 'breathlessness', 
      'sweating', 'dehydration', 'indigestion', 'headache', 'yellowish_skin', 
      'dark_urine', 'nausea', 'loss_of_appetite', 'pain_behind_the_eyes', 'back_pain', 
      'constipation', 'abdominal_pain', 'diarrhoea', 'mild_fever', 'yellow_urine', 
      'yellowing_of_eyes', 'acute_liver_failure', 'fluid_overload', 'swelling_of_stomach', 
      'swelled_lymph_nodes', 'malaise', 'blurred_and_distorted_vision', 'phlegm', 
      'throat_irritation', 'redness_of_eyes', 'sinus_pressure', 'runny_nose', 
      'congestion', 'chest_pain', 'weakness_in_limbs', 'fast_heart_rate', 'pain_during_bowel_movements', 
      'pain_in_anal_region', 'bloody_stool', 'irritation_in_anus', 'neck_pain', 
      'dizziness', 'cramps', 'bruising', 'obesity', 'swollen_legs', 'swollen_blood_vessels', 
      'puffy_face_and_eyes', 'enlarged_thyroid', 'brittle_nails', 'swollen_extremities', 
      'excessive_hunger', 'extra_marital_contacts', 'drying_and_tingling_lips', 
      'slurred_speech', 'knee_pain', 'hip_joint_pain', 'muscle_weakness', 'stiff_neck', 
      'swelling_joints', 'movement_stiffness', 'spinning_movements', 'loss_of_balance', 
      'unsteadiness', 'weakness_of_one_body_side', 'loss_of_smell', 'bladder_discomfort', 
      'foul_smell_of urine', 'continuous_feel_of_urine', 'passage_of_gases', 'internal_itching', 
      'toxic_look_(typhos)', 'depression', 'irritability', 'muscle_pain', 'altered_sensorium', 
      'red_spots_over_body', 'belly_pain', 'abnormal_menstruation', 'dischromic _patches', 
      'watering_from_eyes', 'increased_appetite', 'polyuria', 'family_history', 
      'mucoid_sputum', 'rusty_sputum', 'lack_of_concentration', 'visual_disturbances', 
      'receiving_blood_transfusion', 'receiving_unsterile_injections', 'coma', 
      'stomach_bleeding', 'distention_of_abdomen', 'history_of_alcohol_consumption', 
      'fluid_overload', 'blood_in_sputum', 'prominent_veins_on_calf', 'palpitations', 
      'painful_walking', 'pus_filled_pimples', 'blackheads', 'scurring', 'skin_peeling', 
      'silver_like_dusting', 'small_dents_in_nails', 'inflammatory_nails', 'blister', 
      'red_sore_around_nose', 'yellow_crust_ooze']

# Filter l1 to include only symptoms that exist in df_train
l1 = [symptom for symptom in l1 if symptom in df_train.columns]

X_train = df_train[l1]
y_train = df_train['prognosis']

X_test = df_test[l1]
y_test = df_test['prognosis']

# Utility function for symptom input
def get_symptom_input(symptoms, all_symptoms):
    symptom_vector = [0] * len(all_symptoms)
    for symptom in symptoms:
        if symptom in all_symptoms:
            symptom_vector[all_symptoms.index(symptom)] = 1
    return [symptom_vector]

# Helper functions for CNN model
def get_className(classNo):
    return "No Brain Tumor" if classNo == 0 else "Yes Brain Tumor"

def getResult(img):
    image = cv2.imread(img)
    image = Image.fromarray(image, 'RGB')
    image = image.resize((64, 64))
    image = np.array(image)
    input_img = np.expand_dims(image, axis=0)
    
    result = np.argmax(cnn_model.predict(input_img), axis=-1)
    return result

# Flask routes
@app.route('/', methods=['GET'])
def index():
    return render_template('index.html', symptoms=l1)

@app.route('/predict', methods=['POST'])
def predict():
    # Symptom-based disease prediction (Medinosis)
    psymptoms = [request.form['symptom1'], request.form['symptom2'], request.form['symptom3'], request.form['symptom4'], request.form['symptom5']]
    input_test = get_symptom_input(psymptoms, l1)

    # Decision Tree
    clf_tree = tree.DecisionTreeClassifier().fit(X_train, y_train)
    prediction_tree = clf_tree.predict(input_test)[0]
    disease_tree = reverse_disease_dict.get(prediction_tree, "Disease Not Found")

    # Random Forest
    clf_rf = RandomForestClassifier().fit(X_train, y_train)
    prediction_rf = clf_rf.predict(input_test)[0]
    disease_rf = reverse_disease_dict.get(prediction_rf, "Disease Not Found")

    # Naive Bayes
    clf_nb = GaussianNB().fit(X_train, y_train)
    prediction_nb = clf_nb.predict(input_test)[0]
    disease_nb = reverse_disease_dict.get(prediction_nb, "Disease Not Found")

    # Render the result page with all three predictions
    return render_template('result.html', 
                           prediction_tree=disease_tree,
                           prediction_rf=disease_rf,
                           prediction_nb=disease_nb)

@app.route('/upload', methods=['POST'])
def upload():
    # Brain tumor classification (CNN)
    f = request.files['file']
    basepath = os.path.dirname(__file__)
    file_path = os.path.join(basepath, 'uploads', secure_filename(f.filename))
    f.save(file_path)
    value = getResult(file_path)
    result = get_className(value)
    return result

@app.route('/predict_vegf', methods=['POST'])
def predict_vegf():
    # VEGF prediction (LSTM)
    vegf_levels = [
        float(request.form.get('vegf_level_1')),
        float(request.form.get('vegf_level_2')),
        float(request.form.get('vegf_level_3'))
    ]
    
    # Scale the VEGF levels
    vegf_levels_scaled = scaler.transform(np.array(vegf_levels).reshape(1, -1))
    vegf_levels_scaled = vegf_levels_scaled.reshape((vegf_levels_scaled.shape[0], 1, vegf_levels_scaled.shape[1]))

    # Make prediction using LSTM model
    prediction = lstm_model.predict(vegf_levels_scaled)
    return jsonify({'prediction': int(prediction[0][0] > 0.5)})  # Assuming binary classification

if __name__ == '__main__':
    app.run(debug=True)
