$(document).ready(function () {
    // Init
    $('.image-section').hide();
    $('.loader').hide();
    $('#result').hide();
    $('#vegf-result').hide();

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#imagePreview').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#imageUpload").change(function () {
        $('.image-section').show();
        $('#btn-predict').show();
        $('#result').text('');
        $('#result').hide();
        readURL(this);
    });

    // Predict for CNN
    $('#btn-predict').click(function () {
        var form_data = new FormData($('#upload-file')[0]);

        // Show loading animation
        $(this).hide();
        $('.loader').show();

        // Make prediction by calling api /predict
        $.ajax({
            type: 'POST',
            url: '/predict',
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            async: true,
            success: function (data) {
                // Get and display the result
                $('.loader').hide();
                $('#result').fadeIn(600);
                $('#result').text(' Result:  ' + data);
                console.log('Success!');
            },
        });
    });

    // Predict for VEGF
    $('#btn-predict-vegf').click(function () {
        var vegfData = {
            vegf_level_1: $('input[name="vegf_level_1"]').val(),
            vegf_level_2: $('input[name="vegf_level_2"]').val(),
            vegf_level_3: $('input[name="vegf_level_3"]').val()
        };

        // Show loading animation
        $(this).hide();
        $('.loader').show();

        // Make prediction by calling api /predict_vegf
        $.ajax({
            type: 'POST',
            url: '/predict_vegf',
            data: vegfData,
            success: function (data) {
                // Get and display the result
                $('.loader').hide();
                $('#vegf-result').fadeIn(600);
                $('#vegf-result').text('VEGF Prediction: ' + (data.prediction === 1 ? "Yes Brain Tumor" : "No Brain Tumor"));
                console.log('Success!');
            },
        });
    });
});
