import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler
import joblib  # For loading the scaler

# Load the trained model
model = load_model('vegf_model.h5')

# Load the scaler
scaler = joblib.load('scaler.pkl')  # Assuming you've saved the scaler as a pickle file

# Example new VEGF levels
new_vegf_levels = np.array([[120.0, 130.0, 140.0]])  # Example values

# Scale the new data
new_vegf_levels_scaled = scaler.transform(new_vegf_levels)

# Reshape for LSTM input
new_vegf_levels_scaled = new_vegf_levels_scaled.reshape((new_vegf_levels_scaled.shape[0], 1, new_vegf_levels_scaled.shape[1]))

# Make predictions
prediction = model.predict(new_vegf_levels_scaled)
print("Predicted Tumor Risk:", prediction)
