import pandas as pd
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.optimizers import Adam
import joblib  # For saving the scaler

# Load the VEGF data
df = pd.read_csv('vegf_tumor_data_updated.csv')

# Prepare the features and labels
X = df[['VEGF_Level_1', 'VEGF_Level_2', 'VEGF_Level_3']].values
y = df['Tumor'].values

# Reshape input to be [samples, time steps, features]
X = X.reshape((X.shape[0], 1, X.shape[1]))

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale the data using MinMaxScaler
scaler = MinMaxScaler()
X_train = scaler.fit_transform(X_train.reshape(-1, 3)).reshape(X_train.shape)
X_test = scaler.transform(X_test.reshape(-1, 3)).reshape(X_test.shape)

# Save the scaler
joblib.dump(scaler, 'scaler.pkl')  # Save the scaler to a file

# Build the LSTM model
model = Sequential()

# Add 8 LSTM layers
for i in range(8):
    if i < 7:
        model.add(LSTM(128, activation='relu', return_sequences=True, 
                       input_shape=(X_train.shape[1], X_train.shape[2])) if i == 0 else LSTM(128, activation='relu', return_sequences=True))
    else:
        model.add(LSTM(128, activation='relu', return_sequences=False))
    
    # Add a dropout layer after each LSTM layer
    model.add(Dropout(0.3))

# Additional Dense layers for output
model.add(Dense(64, activation='relu'))
model.add(Dropout(0.3))

# Output layer
model.add(Dense(1, activation='sigmoid'))  # 'Tumor' output

# Compile the model
model.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])

# Train the model
history = model.fit(X_train, y_train, epochs=200, batch_size=32, validation_data=(X_test, y_test))

# Save the model
model.save('vegf_model.h5')
